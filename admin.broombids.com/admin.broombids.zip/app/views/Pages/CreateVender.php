<style type="text/css">
	.btn-group
	{
		width: 100%;
		margin-bottom: 30px;
	}
	.active_btn
	{
		background: #2cc1d6 !important;
	}

.multiselect-selected
{
  border: 1px solid #dad8e4;
  padding: 10px;
  border-radius: 3px;
  width: 100%;
}
.multiselect-list
{
  background: #eee;
}
.multiselect-list div
{
    padding: 10px;
}
.selected-option
{
  background: #50555580;
  color: #ffffff;
}
.multiselect-selected span
{
  background: #eee;
  padding: 5px 10px;
  margin: 0px 5px;
}

.btnplus
{
  padding: 13px;
    border-radius: 0px 3px 3px 0px;
    background: #eee;
    color: #000;
}
.btndelete
{
    padding: 13px;
    border-radius: 0px 3px 3px 0px;
    background: #F8C471;
    color: #000;
}
</style>
<div class="col-md-12">
<div class="card card-statistics">
    <div class="card-header">
        <div class="card-heading">
            <h4 class="card-title">Create New Vender</h4>
        </div>
    </div>
    <div class="card-body">
    	<div class="btn-group btn-group-lg" >
            <button type="button" class="btn btn-square btn-secondary active_btn" id="stepbtn1">PERSONAL INFORMATION</button>
            <button type="button" class="btn btn-square btn-secondary" id="stepbtn2">BUSINESS INFORMATION</button>
            <button type="button" class="btn btn-square btn-secondary" id="stepbtn3">VEHICLE INFORMATION</button>
            
        </div>

        <div id="err"></div>
        <form id="form_addlead" action="ajaxupload.php" method="post" enctype="multipart/form-data">
            <div class="form-row" id="step1" >
            	<div class="form-group col-md-12">
                    <label for="fname">Select Business Type</label>
                    <select class="form-control" name="businesstype" id="businesstype">
	                  	<option value="">Select Business Type</option>
	                  	<option value="Car Rental Business">Car Rental Business</option>
	                  	<option value="Travel Agent">Travel Agent</option>
	                  </select>
                </div>

                <div class="form-group col-md-6">
                    <label for="fname">First Name</label>
                    <input type="text" class="form-control" id="fname" name="fname" placeholder="Enter First Name">
                </div>
                <div class="form-group col-md-6">
                    <label for="surname">Surname</label>
                    <input type="text" class="form-control" id="surname" name="surname" placeholder="Enter Surname">
                </div>
                <div class="form-group col-md-6">
                    <label for="phone">Contact Number</label>
                    <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter Contact Number">
                </div>
                <div class="form-group col-md-6">
                    <label for="email">Email Address</label>
                    <input type="text" class="form-control" id="email" name="email" placeholder="Enter Email Address">
                </div>
                <div class="form-group col-md-6">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password">
                </div>
                <div class="form-group col-md-6">
                    <label for="repassword">Confirm Password</label>
                    <input type="password" class="form-control" id="repassword" name="repassword" placeholder="Enter Confirm Password">
                </div>
                <div class="form-group col-md-6">

                </div>
                <div class="form-group col-md-6">
                	<button type="button" id="goto_step2" class="btn btn-primary" style="width: 100%;"> NEXT</button>
                </div>
                
            </div> 

            <div class="form-row" id="step2" style="display: none;">
            	<div class="form-group col-md-12">
            		<label id="title">Select Bussness Logo</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="inputGroupFileAddon01">Bussness Logo</span>
                        </div>
                        <div class="custom-file">
                            <input type="file" name="blogo" class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
                            <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                        </div>
                    </div>
                </div>

                <div class="form-group col-md-6" id="bnamebox">
                    <label for="fname">Bussness Name</label>
                    <input type="text" class="form-control" id="bname" name="bname" placeholder="Enter Bussness Name">
                </div>
                <div class="form-group col-md-6">
                    <label for="phone">VAT ID</label>
                    <input type="text" class="form-control" id="vatid" name="vatid" placeholder="Enter VAT Number">
                </div>
                
                <div id="multi-select4" class="form-group" style="width: 100%;">
					  <select class="form-control">
					    <?php
							$newUser=new Users();
							$locationsadmins = $newUser->FindByAll('locationsadmin');
							if($locationsadmins)
							{
								foreach ($locationsadmins as $locationsadmin) 
								{
									echo '<option value="'.$locationsadmin->lname.'">'.$locationsadmin->lname.'</option>';
								}
							}
						?>
					  </select>
					  <input type="hidden" name="locations" id="locations"  placeholder="Selected Values"/>
					</div>

					<div id="locationbox" class="form-row" style="width: 100%;"></div>

                <div class="form-group col-md-6">
                  <button type="button" class="btn btn-secondary" id="back_step1" style="width: 100%;"> BACK</button>
                </div>
                <div class="form-group col-md-6">
                	<button type="button" class="btn btn-primary" id="goto_step3" style="width: 100%;"> NEXT</button>
                </div>
                
            </div>

            <div class="form-row" id="step3" style="display: none;">
            	<div id="multi-select" class="form-group" style="width: 100%;">
					  <select class="form-control">
					    <option value="SUV">SUV</option>
					    <option value="Truck">Truck</option>
					    <option value="Sedan">Sedan</option>
					    <option value="Van">Van</option>
					    <option value="Coupe">Coupe</option>
					  </select>
					  <input type="hidden" name="vehicletype" id="vehicletype" placeholder="Selected Values"/>
					</div>

					<div id="multi-select2" class="form-group" style="width: 100%;">
					  <select class="form-control">
					    <option value="Tesla">Tesla</option>
					    <option value="BMW">BMW</option>
					    <option value="Ferrari">Ferrari</option>
					    <option value="Ford">Ford</option>
					    <option value="Maruti Suzuki">Maruti Suzuki</option>
					  </select>
					  <input type="hidden" name="vehiclecompany" id="vehiclecompany" placeholder="Selected Values"/>
					</div>

					<div id="multi-select3" class="form-group" style="width: 100%;">
					  <select class="form-control">
					    <option value="Suzuki Swift">Suzuki Swift</option>
					    <option value="Suzuki Dzire">Suzuki Dzire</option>
					    <option value="Suzuki Vitara Brezza">Suzuki Vitara Brezza</option>
					  </select>
					  <input type="hidden" name="vehiclename" id="vehiclename" placeholder="Selected Values"/>
					</div>
            <div class="form-group col-md-6">
                  <button type="button" class="btn btn-secondary" id="back_step2" style="width: 100%;"> BACK</button>
                </div>
            <div class="form-group col-md-6">
            	<button type="submit" class="btn btn-primary" style="width: 100%;"> SUBMIT</button>
            </div>
            </div>
            
        </form>
    </div>
</div>
</div>
<script type="text/javascript" src="<?=PROOT?>dist/jquery.multiselect.js"></script>
<script type="text/javascript">

  $(function(){
  $("#multi-select").multiSelect({
    label: 'Select Vehicle Type'
  });
  $("#multi-select2").multiSelect({
    label: 'Select Vehicle Company'
  });
  $("#multi-select3").multiSelect({
    label: 'Select Vehicle Name'
  });
  $("#multi-select4").multiSelect({
    label: 'Select Locations'
  });
});


  $(document).ready(function (e) {
 $("#form_addlead").on('submit',(function(e) {
  e.preventDefault();
  $.ajax({
         url: path+"Master/VenderRegister",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   beforeSend : function()
   {
    $("#err").fadeOut();
    $("#err").fadeOut();
    $("#err").html('<div class="alert dark alert-info alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>Authentication....</div>').fadeIn();
   },
   success: function(data)
      {
    if(data=='success')
    {
     // invalid file format.
     $("#err").html('<div class="alert dark alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>Vender registered successfully.</div>').fadeIn();
     $("#form_addlead")[0].reset(); 
     $("#step4").fadeOut(500);
	 $("#step1").fadeIn(1000);
	 document.body.scrollTop = 0;
  	 document.documentElement.scrollTop = 0;
    }
    else
    {
     // view uploaded file.
     $("#err").html('<div style="margin-left: 0px; width: 100%;" class="alert alert-warning"><strong>Opps!</strong> '+data+'</div>').fadeIn();
     //$("#form")[0].reset(); 
     
    }
      },
     error: function(e) 
      {
    $("#err").html(e).fadeIn();
      }          
    });
 }));
});
</script>