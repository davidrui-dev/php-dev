<style>
	.secret_container{
	    text-align: center;
    	padding-top: 10px;
	}
	.secret_loc_img img{
		width: 30%;
	}
	.secret_text h2{
		font-size: 20px;
		margin-bottom: 10px;
	}
	.secret_text p{
		font-size: 14px;
    	margin-top: 0px;
	}
</style>
<div class="secret_container">
	<div class="secret_loc_img">
		<img src="<?=PROOT?>images/secret_lock.svg"/>
	</div>
	<div class="secret_text">
		<h2>This Identity's Account is Secret</h2>
		<p>Follow this Identity to view their Pride.</p>
	</div>
</div>

