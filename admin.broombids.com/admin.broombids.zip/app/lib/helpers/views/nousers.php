<?php $this->setSiteTitle('Profile View'); ?>
<?php $this->start('head'); ?>

<?php $this->end(); ?>

<?php $this->start('body');


?>

<div class="globalPrimeViewContainer">
    No User
</div>
<?php require_once(ROOT.DS.'app'.DS.'views'.DS.'layouts'.DS.'footer'.'.php'); ?>



<?php $this->end(); ?>
